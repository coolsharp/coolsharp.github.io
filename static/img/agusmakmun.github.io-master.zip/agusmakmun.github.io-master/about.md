---
layout: page
title: About
permalink: /about/
---

I am freelance developer. Currently doing more in backend, focused in Python and Django.

email: agus[at]python.web.id
